document.addEventListener('DOMContentLoaded', function(){
    setTimeout(function(){
        window.location.href='home.html';        
    },4000);    
})
